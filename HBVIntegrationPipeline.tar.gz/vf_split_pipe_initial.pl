$dir=$ARGV[0];#/sc/orga/projects/zhuj05a/Wenhui/HBV/script/wgs_88/11/normal

$cmd="mkdir $dir/virus_seq";
`$cmd`;
$cmd="mkdir $dir/virusfinder";
`$cmd`;
$cmd="mkdir $dir/virusfinder1";
`$cmd`;
$cmd="mkdir $dir/virusfinder1/align_hsa";
`$cmd`;
$cmd="mkdir $dir/virusfinder1/output";
`$cmd`;
$cmd="mkdir $dir/virusfinder1/output/step1";
`$cmd`;
$cmd="mkdir $dir/virusfinder1/output/step2";
`$cmd`;
$cmd="mkdir $dir/virusfinder1/output/step3";
`$cmd`;
$cmd="mkdir $dir/virusfinder1/output/step3/b-axis";
`$cmd`;
